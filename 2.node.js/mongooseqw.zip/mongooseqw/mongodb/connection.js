//引入mongoose 模块
let mongoose = require('mongoose')
//连接数据库
mongoose.connect('mongodb://127.0.0.1:27017/qy128', {
  useUnifiedTopology: true,
  useNewUrlParser: true
});
//获取连接状态
var db = mongoose.connection;
db.on('error', function (error) {
  if (error) {
    console.log('数据库连接失败');
  }
})
db.on('open', function () {
  console.log('数据库连接成功');

})
db.on('disconnected', function () {
  console.log('数据库连接断开');
})

module.exports = mongoose;