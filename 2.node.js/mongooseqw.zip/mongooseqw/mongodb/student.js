let mongoose = require('mongoose');
//定义文档形式 (Schema)
let Schema_ = new mongoose.Schema({
    oldname: {
        type: String,
        required: true
    },
    sg: {
        type: Number
    },
    tz: {
        type: Number
    },
    jn: {
        type: String
    }
});

//将schema映射给某个集合
var studentModel = mongoose.model('student', Schema_);
module.exports = studentModel;