let mongoose = require('./connection.js');
//定义文档形式 (Schema)
let predSchema = new mongoose.Schema({
    oldname: {
        type: String,
        required: true
    },
    sg: String,
    tz: String,
    jn: {
        type: String
    }
});

//将schema映射给某个集合
var predModel = mongoose.model('pred', predSchema);
module.exports = predModel;