var express = require('express');
const app = require('../app');
var router = express.Router();
// let studentModel = require('./../mongodb/student.js');
/* GET users listing. */
router.get('/', function(req, res, next) {
  
  // studentModel.create();
});
// app.listen(3000);
module.exports = router;
