var express = require('express');
const app = require('../app.js');
var router = express.Router();
let predModel = require('./../mongodb/predeSchema.js');
//添加
router.get('/add', function (req, res, next) {
  /*  res.render('index', {
     title: 'Express'
   }); */
  let {
    oldname,
    sg,
    tz,
    jn
  } = req.query;
  predModel.create({
    oldname,
    sg,
    tz,
    jn

  }, (err, data) => {
    if (err) {
      throw err
    }
    res.send(JSON.stringify(data));
  })
});
//修改
router.get('/update', function (req, res, next) {
  let {
    _id,
    newname,
    newsg,
    newtz,
    newjn
  } = req.query;
  predModel.updateOne({
    _id
  }, {
    $set: {
      oldname: newname,
      sg: newsg,
      tz: newtz,
      jn: newjn

    }
  }, (err) => {
    if (err) throw err;
  })
  res.send('update_over');
});
//查找
router.get('/find', function (req, res, next) {
  let {
    oldname
  } = req.query;
  console.log(oldname);
  predModel.find({
    oldname
  }, {
    '__v': 0
  }, (err, data) => {
    if (err) {
      throw err
    };
    res.send(JSON.stringify(data));
  }).sort({
    age: -1
  });
});

router.get('/find2', function (req, res, next) {
  // let {oldname:oldname} = req.query;
  predModel.find({}, {
    '__v': 0
  }, (err, data) => {
    if (err) {
      throw err
    };
    res.send(JSON.stringify(data));
  }).sort({
    age: -1
  });
});
// 删除
router.get('/remove', function (req, res, next) {
  let {
    _id
  } = req.query;
  predModel.remove({
    _id
  }, (err) => {
    if (err) {
      throw err
    }
    res.send('下一个');
  });
});
// app.listen(3000);
module.exports = router;